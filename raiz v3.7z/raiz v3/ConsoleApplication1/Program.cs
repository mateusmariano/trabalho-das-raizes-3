﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("digite o número que queira saber a raíz");
            int n = int.Parse(Console.ReadLine());
            int x = 1;
            int sub = 1;
            int cont = 0;

            while (n > 0)
            {
                n = n - x;
                x = x + 2;
                cont = cont + 1;
            }
            if (n < 0)
            {
                Type type = typeof(ConsoleColor);
                Console.ForegroundColor = ConsoleColor.Black;
                Console.BackgroundColor = ConsoleColor.Red;
                Console.WriteLine("não existe raiz exata");
            }
            else
            {
                Type type = typeof(ConsoleColor);
                Console.ForegroundColor = ConsoleColor.Black;
                Console.BackgroundColor = ConsoleColor.Green;
               
                Console.WriteLine("a raiz do numero é " + cont);
            }
        }        
    }
}
